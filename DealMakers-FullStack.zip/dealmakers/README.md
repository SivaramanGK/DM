# Deal Makers — Full Stack Real Estate Platform

Original real-estate marketplace web app (zero-brokerage style) with separate buyer and seller flows, built from scratch. Includes a working Node.js backend, a React frontend, and a Capacitor wrapper for building an installable Android APK.

This is independent, original software — not a copy of any existing company's code, design assets, or branding.

---

## What's inside

```
dealmakers/
├── backend/          Node.js + Express API (auth, properties, images, enquiries, favorites)
└── frontend/          React + Vite web app (also wraps into Android APK via Capacitor)
```

### Features
- Buyer login/register and Seller login/register (separate flows, JWT auth)
- Seller dashboard: upload properties with square footage, address, pincode, GPS coordinates, amenities, multiple photos
- Buyer listings: search, filters (price/area/BHK/type), Rent vs Buy toggle, sort
- Map view of all listings (Leaflet + OpenStreetMap, no API key required)
- Favorites / saved properties for buyers
- Owner contact details (phone/email) are **never sent** to buyer-facing endpoints — only revealed to the seller when a buyer submits an enquiry
- Image upload (up to 8 photos per listing, 5MB each)
- Data persists on disk (JSON file) — survives server restarts
- PWA-ready (installable from a browser) and Capacitor-ready (buildable into a native Android APK)

---

## 1. Running the backend

```bash
cd backend
npm install
npm start
```

Runs on **http://localhost:4000**. Data is stored in `backend/data/db.json` (auto-created). Uploaded images are stored in `backend/uploads/`.

Optional: create a `.env` file in `backend/` to set a custom JWT secret:
```
JWT_SECRET=replace_with_a_long_random_string
PORT=4000
```

---

## 2. Running the frontend (web)

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Runs on **http://localhost:5173** and proxies `/api` and `/uploads` requests to the backend automatically (see `vite.config.js`). Open that URL in your browser — register as a seller, upload a property, then register as a buyer in a different browser/incognito tab to see it listed.

### Building for production (static web hosting)
```bash
npm run build
```
Output goes to `frontend/dist/` — deployable to any static host (Netlify, Vercel, S3, etc.), as long as your backend is reachable and CORS is configured for your domain.

---

## 3. Installing as a PWA (no app store needed)

Once `npm run build` is deployed and served over HTTPS, visit the site on a phone — Chrome/Edge will offer "Add to Home Screen" / "Install App" automatically, using the icons and manifest already configured in `frontend/public/manifest.json`.

---

## 4. Building an Android APK

This step requires **Android Studio and a JDK installed on your own computer** — it cannot be done inside this sandboxed environment. Once you have those installed:

```bash
cd frontend
npm install
npm run build
npx cap add android
npx cap copy android
npx cap open android
```

The last command opens the generated Android project in Android Studio. From there:
1. Let Gradle sync finish (first time may take a few minutes)
2. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. Find the generated `.apk` under `frontend/android/app/build/outputs/apk/debug/`

For a **signed release APK** (required to publish on the Play Store), use **Build → Generate Signed Bundle / APK** in Android Studio and follow the keystore wizard.

### Important: point the app at your live backend
Before building the APK, the app needs a real, internet-reachable backend URL (it can't use `localhost`, since that means the phone itself). Update `frontend/src/api.js`:

```js
const API_BASE = "https://your-deployed-backend.com/api";
```

Then rebuild (`npm run build`) before running the Capacitor steps above. You'll need to deploy the `backend/` folder somewhere reachable — e.g. Render, Railway, Fly.io, or your own server — since this sandbox cannot host it for you long-term.

---

## 5. Default test flow

1. Start backend, then frontend
2. Go to `http://localhost:5173`
3. Click **"I'm a Seller"** → Create account → upload a property (fill required fields: title, area, address, pincode)
4. Sign out, click **"I'm a Buyer"** → Create account → see the listing appear, use filters/map/favorites
5. Click into the property → submit an enquiry
6. Sign back in as the seller → **Enquiries Received** tab shows the buyer's contact details

---

## Notes & limitations

- The included database is a simple JSON file (via `lowdb`) — fine for development/demo, not for production scale. For production, swap in PostgreSQL/MySQL/MongoDB behind the same API routes.
- Map coordinates are entered manually by the seller (latitude/longitude) since no paid Maps API key is configured. You can wire in Google Maps Places Autocomplete later if you have an API key.
- This project ships with placeholder app icons (`frontend/public/icons/`) — swap them with your real logo before publishing.
- `JWT_SECRET` defaults to a development value — always set your own in production via `.env`.
