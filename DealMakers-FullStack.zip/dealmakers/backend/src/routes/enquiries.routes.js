const express = require("express");
const db = require("../db");
const { authMiddleware, requireRole } = require("../auth");

const router = express.Router();

// POST /api/enquiries - buyer requests a visit / contact for a property
router.post("/", authMiddleware, requireRole("buyer"), (req, res) => {
  const { propertyId, message, preferredDate } = req.body;
  if (!propertyId) return res.status(400).json({ error: "propertyId is required" });

  const prop = db.get("properties").find({ id: propertyId }).value();
  if (!prop) return res.status(404).json({ error: "Property not found" });

  const enquiry = {
    id: "e_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
    propertyId,
    buyerId: req.user.id,
    buyerName: req.user.name,
    buyerEmail: req.user.email,
    sellerId: prop.ownerId,
    message: message || "",
    preferredDate: preferredDate || "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  db.get("enquiries").push(enquiry).write();
  res.status(201).json({
    enquiry,
    note: "Your request has been sent to the seller. They will contact you to confirm the visit.",
  });
});

// GET /api/enquiries/mine - buyer sees their own enquiries
router.get("/mine", authMiddleware, requireRole("buyer"), (req, res) => {
  const mine = db.get("enquiries").filter({ buyerId: req.user.id }).value();
  res.json({ count: mine.length, enquiries: mine });
});

// GET /api/enquiries/received - seller sees enquiries for their properties (buyer contact revealed here)
router.get("/received", authMiddleware, requireRole("seller"), (req, res) => {
  const received = db.get("enquiries").filter({ sellerId: req.user.id }).value();
  res.json({ count: received.length, enquiries: received });
});

module.exports = router;
