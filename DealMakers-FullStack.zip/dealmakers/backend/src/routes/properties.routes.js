const express = require("express");
const db = require("../db");
const { authMiddleware, requireRole } = require("../auth");
const upload = require("../upload");

const router = express.Router();

function publicProperty(p) {
  // Strip seller contact details before sending to buyers
  const { ownerPhone, ownerEmail, ownerId, ...safe } = p;
  return safe;
}

// GET /api/properties - public listing with search & filters
router.get("/", (req, res) => {
  const {
    q,
    type,
    listingType, // "rent" | "buy"
    minPrice,
    maxPrice,
    minArea,
    maxArea,
    bhk,
    city,
    pincode,
    amenities,
    sort,
  } = req.query;

  let results = db.get("properties").value() || [];

  if (q) {
    const term = q.toLowerCase();
    results = results.filter(
      (p) =>
        p.title.toLowerCase().includes(term) ||
        p.address.toLowerCase().includes(term) ||
        (p.description || "").toLowerCase().includes(term) ||
        (p.landmark || "").toLowerCase().includes(term)
    );
  }
  if (type) results = results.filter((p) => p.type === type);
  if (listingType) results = results.filter((p) => p.listingType === listingType);
  if (city) results = results.filter((p) => p.address.toLowerCase().includes(city.toLowerCase()));
  if (pincode) results = results.filter((p) => p.pincode === pincode);
  if (bhk) results = results.filter((p) => p.bhk === bhk);
  if (minPrice) results = results.filter((p) => Number(p.priceValue) >= Number(minPrice));
  if (maxPrice) results = results.filter((p) => Number(p.priceValue) <= Number(maxPrice));
  if (minArea) results = results.filter((p) => Number(p.area) >= Number(minArea));
  if (maxArea) results = results.filter((p) => Number(p.area) <= Number(maxArea));
  if (amenities) {
    const required = amenities.split(",").map((a) => a.trim());
    results = results.filter((p) => required.every((a) => (p.amenities || []).includes(a)));
  }

  if (sort === "price_asc") results = [...results].sort((a, b) => a.priceValue - b.priceValue);
  else if (sort === "price_desc") results = [...results].sort((a, b) => b.priceValue - a.priceValue);
  else if (sort === "area_desc") results = [...results].sort((a, b) => b.area - a.area);
  else results = [...results].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({ count: results.length, properties: results.map(publicProperty) });
});

// GET /api/properties/:id
router.get("/:id", (req, res) => {
  const prop = db.get("properties").find({ id: req.params.id }).value();
  if (!prop) return res.status(404).json({ error: "Property not found" });
  res.json({ property: publicProperty(prop) });
});

// POST /api/properties - seller creates listing (with image upload)
router.post("/", authMiddleware, requireRole("seller"), upload.array("images", 8), (req, res) => {
  const {
    title,
    type,
    listingType,
    price,
    priceValue,
    area,
    bhk,
    floor,
    facing,
    address,
    pincode,
    mapLat,
    mapLng,
    landmark,
    description,
    amenities,
  } = req.body;

  if (!title || !area || !address || !pincode) {
    return res.status(400).json({ error: "title, area, address, and pincode are required" });
  }

  const user = db.get("users").find({ id: req.user.id }).value();
  const imageFiles = (req.files || []).map((f) => `/uploads/${f.filename}`);

  let amenitiesArr = [];
  try {
    amenitiesArr = typeof amenities === "string" ? JSON.parse(amenities) : amenities || [];
  } catch {
    amenitiesArr = [];
  }

  const property = {
    id: "p_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
    title,
    type: type || "Apartment",
    listingType: listingType === "rent" ? "rent" : "buy",
    price: price || "Price on request",
    priceValue: Number(priceValue) || 0,
    area: Number(area),
    bhk: bhk || "",
    floor: floor || "",
    facing: facing || "",
    address,
    pincode,
    mapLat: mapLat ? Number(mapLat) : null,
    mapLng: mapLng ? Number(mapLng) : null,
    landmark: landmark || "",
    description: description || "",
    amenities: amenitiesArr,
    images: imageFiles,
    ownerId: user.id,
    ownerName: user.name,
    ownerPhone: user.phone,
    ownerEmail: user.email,
    createdAt: new Date().toISOString(),
  };

  db.get("properties").push(property).write();
  res.status(201).json({ property: publicProperty(property) });
});

// GET /api/properties/mine/list - seller's own properties (with contact info visible to them)
router.get("/mine/list", authMiddleware, requireRole("seller"), (req, res) => {
  const mine = db.get("properties").filter({ ownerId: req.user.id }).value();
  res.json({ count: mine.length, properties: mine });
});

// DELETE /api/properties/:id - seller deletes own listing
router.delete("/:id", authMiddleware, requireRole("seller"), (req, res) => {
  const prop = db.get("properties").find({ id: req.params.id }).value();
  if (!prop) return res.status(404).json({ error: "Property not found" });
  if (prop.ownerId !== req.user.id) return res.status(403).json({ error: "Not your listing" });
  db.get("properties").remove({ id: req.params.id }).write();
  res.json({ success: true });
});

// ── FAVORITES ──
// POST /api/properties/:id/favorite - toggle favorite for buyer
router.post("/:id/favorite", authMiddleware, requireRole("buyer"), (req, res) => {
  const propId = req.params.id;
  const prop = db.get("properties").find({ id: propId }).value();
  if (!prop) return res.status(404).json({ error: "Property not found" });

  const existing = db.get("favorites").find({ userId: req.user.id, propertyId: propId }).value();
  if (existing) {
    db.get("favorites").remove({ userId: req.user.id, propertyId: propId }).write();
    return res.json({ favorited: false });
  } else {
    db.get("favorites")
      .push({ userId: req.user.id, propertyId: propId, createdAt: new Date().toISOString() })
      .write();
    return res.json({ favorited: true });
  }
});

// GET /api/properties/favorites/mine - buyer's favorite properties
router.get("/favorites/mine", authMiddleware, requireRole("buyer"), (req, res) => {
  const favs = db.get("favorites").filter({ userId: req.user.id }).value();
  const ids = favs.map((f) => f.propertyId);
  const props = db.get("properties").filter((p) => ids.includes(p.id)).value();
  res.json({ count: props.length, properties: props.map(publicProperty) });
});

module.exports = router;
