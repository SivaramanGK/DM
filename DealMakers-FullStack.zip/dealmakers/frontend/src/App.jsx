import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
import Listings from "./pages/Listings";
import PropertyDetail from "./pages/PropertyDetail";
import Favorites from "./pages/Favorites";
import SellerDashboard from "./pages/SellerDashboard";

export default function App() {
  return (
    <div className="app-shell">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/auth/:role" element={<Auth />} />
        <Route
          path="/listings"
          element={
            <ProtectedRoute role="buyer">
              <Listings />
            </ProtectedRoute>
          }
        />
        <Route path="/property/:id" element={<PropertyDetail />} />
        <Route
          path="/favorites"
          element={
            <ProtectedRoute role="buyer">
              <Favorites />
            </ProtectedRoute>
          }
        />
        <Route
          path="/seller"
          element={
            <ProtectedRoute role="seller">
              <SellerDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}
