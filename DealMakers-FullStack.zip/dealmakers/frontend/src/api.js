const API_BASE = "/api";

function getToken() {
  return localStorage.getItem("dm_token");
}

async function request(path, options = {}) {
  const headers = options.headers || {};
  if (!options.isFormData) headers["Content-Type"] = "application/json";
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
    body: options.body
      ? options.isFormData
        ? options.body
        : JSON.stringify(options.body)
      : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  register: (payload) => request("/auth/register", { method: "POST", body: payload }),
  login: (payload) => request("/auth/login", { method: "POST", body: payload }),

  listProperties: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== "" && v !== undefined && v !== null)
    ).toString();
    return request(`/properties${qs ? "?" + qs : ""}`);
  },
  getProperty: (id) => request(`/properties/${id}`),
  createProperty: (formData) =>
    request("/properties", { method: "POST", body: formData, isFormData: true }),
  myProperties: () => request("/properties/mine/list"),
  deleteProperty: (id) => request(`/properties/${id}`, { method: "DELETE" }),
  toggleFavorite: (id) => request(`/properties/${id}/favorite`, { method: "POST" }),
  myFavorites: () => request("/properties/favorites/mine"),

  sendEnquiry: (payload) => request("/enquiries", { method: "POST", body: payload }),
  myEnquiries: () => request("/enquiries/mine"),
  receivedEnquiries: () => request("/enquiries/received"),
};

export { getToken };
