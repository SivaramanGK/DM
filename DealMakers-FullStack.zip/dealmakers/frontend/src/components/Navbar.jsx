import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <nav className="navbar">
      <div className="nav-logo" onClick={() => navigate(user.role === "seller" ? "/seller" : "/listings")}>
        <span className="dia" /> Deal Makers
      </div>
      <div className="nav-right">
        {user.role === "buyer" && (
          <button className="nav-link-btn" onClick={() => navigate("/favorites")}>
            ♥ Favorites
          </button>
        )}
        <span className="nav-user-name">
          {user.name} · {user.role === "seller" ? "Seller" : "Buyer"}
        </span>
        <div className={`nav-avatar ${user.role === "seller" ? "seller" : ""}`}>
          {user.name[0].toUpperCase()}
        </div>
        <button className="btn-logout" onClick={handleLogout}>
          Sign Out
        </button>
      </div>
    </nav>
  );
}
