import { useNavigate } from "react-router-dom";

const ICONS = {
  Apartment: "🏢",
  Villa: "🏠",
  "Independent House": "🏡",
  Commercial: "🏪",
  "Plot / Land": "🌿",
  "Office Space": "🏬",
};

export default function PropertyCard({ property, isFavorited, onToggleFavorite, showFavButton }) {
  const navigate = useNavigate();
  const icon = ICONS[property.type] || "🏠";
  const thumb = property.images && property.images.length > 0 ? property.images[0] : null;

  return (
    <div className="prop-card" onClick={() => navigate(`/property/${property.id}`)}>
      <div className="prop-thumb">
        {thumb ? <img src={thumb} alt={property.title} /> : <span>{icon}</span>}
        <span className={`listing-type-badge ${property.listingType === "rent" ? "lt-rent" : "lt-buy"}`}>
          {property.listingType === "rent" ? "For Rent" : "For Sale"}
        </span>
        {showFavButton && (
          <button
            className={`fav-btn ${isFavorited ? "active" : ""}`}
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(property.id);
            }}
          >
            {isFavorited ? "♥" : "♡"}
          </button>
        )}
      </div>
      <div className="prop-body">
        <div className="prop-price">
          {property.listingType === "rent" ? `₹${property.price}` : property.price}
          {property.listingType === "rent" && <span className="per">/month</span>}
        </div>
        <div className="prop-title-text">{property.title}</div>
        <div className="prop-address">📍 {property.address} – {property.pincode}</div>
        <div className="prop-specs">
          <div className="spec-item">
            <span className="spec-val">{property.area}</span>
            <span className="spec-key">Sq. Ft</span>
          </div>
          <div className="spec-item">
            <span className="spec-val">{property.bhk || "–"}</span>
            <span className="spec-key">Config</span>
          </div>
          <div className="spec-item">
            <span className="spec-val">{property.facing || "–"}</span>
            <span className="spec-key">Facing</span>
          </div>
          <div className="spec-item">
            <span className="spec-val">{property.floor || "–"}</span>
            <span className="spec-key">Floor</span>
          </div>
        </div>
        {property.amenities && property.amenities.length > 0 && (
          <div className="amenity-list">
            {property.amenities.slice(0, 4).map((a) => (
              <span key={a} className="amenity-pill">{a}</span>
            ))}
            {property.amenities.length > 4 && (
              <span className="amenity-pill">+{property.amenities.length - 4}</span>
            )}
          </div>
        )}
        <div className="contact-hidden">
          🔒 Owner contact hidden · <strong>View Details</strong> to enquire
        </div>
      </div>
    </div>
  );
}
