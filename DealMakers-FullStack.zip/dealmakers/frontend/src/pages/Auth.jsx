import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Auth() {
  const { role } = useParams(); // "buyer" or "seller"
  const navigate = useNavigate();
  const { login, register } = useAuth();

  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const isBuyer = role === "buyer";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!email || !password) return setError("Please enter email and password.");
    if (mode === "register" && !name) return setError("Please enter your full name.");

    setLoading(true);
    try {
      const user =
        mode === "login"
          ? await login(email, password)
          : await register(name, email, password, role, phone);
      navigate(user.role === "seller" ? "/seller" : "/listings");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <button className="back-btn" onClick={() => navigate("/")}>← Back to home</button>
        <h2 className="auth-title">{isBuyer ? "Welcome Back" : "Seller Portal"}</h2>
        <p className="auth-subtitle">
          {isBuyer
            ? mode === "login" ? "Sign in to explore exclusive deals" : "Create your free buyer account"
            : mode === "login" ? "Sign in to manage your listings" : "Register to list your properties"}
        </p>

        {error && <div className="error-msg">{error}</div>}

        <form onSubmit={handleSubmit}>
          {mode === "register" && (
            <div className="field">
              <label>Full Name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" />
            </div>
          )}
          <div className="field">
            <label>Email Address</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>
          {mode === "register" && !isBuyer && (
            <div className="field">
              <label>Mobile Number</label>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 XXXXX XXXXX" />
            </div>
          )}
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? <span className="loading-spin" /> : mode === "login" ? "Sign In →" : "Create Account →"}
          </button>
        </form>

        <div className="divider"><span>or</span></div>
        <div className="toggle-link">
          {mode === "login" ? "New here?" : "Already have an account?"}
          <button onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>
            {mode === "login" ? "Create account" : "Sign in"}
          </button>
        </div>
      </div>
    </div>
  );
}
