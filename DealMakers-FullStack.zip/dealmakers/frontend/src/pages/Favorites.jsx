import { useState, useEffect } from "react";
import { api } from "../api";
import PropertyCard from "../components/PropertyCard";

export default function Favorites() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = () => {
    setLoading(true);
    api.myFavorites()
      .then((data) => setProperties(data.properties))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleToggleFavorite = async (id) => {
    try {
      await api.toggleFavorite(id);
      setProperties((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="listing-page">
      <div className="listing-header">
        <div>
          <h1 className="listing-title">Your <em>Favorites</em></h1>
          <p className="listing-count">{loading ? "Loading…" : `${properties.length} saved properties`}</p>
        </div>
      </div>
      {error && <div className="error-msg">{error}</div>}
      <div className="prop-grid">
        {!loading && properties.length === 0 && (
          <div className="no-props">
            <div className="empty-icon">♡</div>
            <p>No favorites yet. Browse listings and tap the heart icon to save properties here.</p>
          </div>
        )}
        {properties.map((p) => (
          <PropertyCard key={p.id} property={p} isFavorited={true} onToggleFavorite={handleToggleFavorite} showFavButton={true} />
        ))}
      </div>
    </div>
  );
}
