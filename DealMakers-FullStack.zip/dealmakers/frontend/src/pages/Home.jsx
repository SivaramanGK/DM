import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="hero">
      <div className="logo-mark">
        <span className="dia" /> Deal Makers <span className="dia" />
      </div>
      <h1 className="hero-headline">
        We Make <em>Super Deals</em><br />That No One Can Match
      </h1>
      <p className="hero-tagline">
        The value we deliver is <strong>unparalleled</strong>. From dream homes to smart
        investments — zero brokerage, maximum value. <strong>No one makes deals like us.</strong>
      </p>
      <div className="login-cards">
        <div className="login-card" onClick={() => navigate("/auth/buyer")}>
          <span className="lc-icon">🔍</span>
          <div className="lc-title">I'm a Buyer</div>
          <p className="lc-sub">Browse verified properties with complete details — find your perfect deal</p>
          <span className="lc-badge badge-gold">Explore Deals</span>
        </div>
        <div className="login-card" onClick={() => navigate("/auth/seller")}>
          <span className="lc-icon">🏷️</span>
          <div className="lc-title">I'm a Seller</div>
          <p className="lc-sub">List your property and reach thousands of serious buyers instantly</p>
          <span className="lc-badge badge-blue">List Property</span>
        </div>
      </div>
    </div>
  );
}
