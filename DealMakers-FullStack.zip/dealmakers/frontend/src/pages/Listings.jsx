import { useState, useEffect, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";
import PropertyCard from "../components/PropertyCard";

const FILTERS = ["All", "Apartment", "Villa", "Independent House", "Commercial", "Plot / Land"];

const goldIcon = new L.Icon({
  iconUrl: "data:image/svg+xml," + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="40" viewBox="0 0 28 40">
      <path d="M14 0C6.3 0 0 6.3 0 14c0 10.5 14 26 14 26s14-15.5 14-26C28 6.3 21.7 0 14 0z" fill="#C9A84C"/>
      <circle cx="14" cy="14" r="6" fill="#0A0F1E"/>
    </svg>`),
  iconSize: [28, 40],
  iconAnchor: [14, 40],
  popupAnchor: [0, -36],
});

export default function Listings() {
  const { user } = useAuth();
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [view, setView] = useState("grid"); // grid | map
  const [listingType, setListingType] = useState(""); // "" | rent | buy
  const [typeFilter, setTypeFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [favIds, setFavIds] = useState(new Set());

  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [minArea, setMinArea] = useState("");
  const [bhk, setBhk] = useState("");
  const [sort, setSort] = useState("");

  const fetchProperties = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const params = {
        q: search,
        type: typeFilter === "All" ? "" : typeFilter,
        listingType,
        minPrice,
        maxPrice,
        minArea,
        bhk,
        sort,
      };
      const data = await api.listProperties(params);
      setProperties(data.properties);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [search, typeFilter, listingType, minPrice, maxPrice, minArea, bhk, sort]);

  useEffect(() => {
    fetchProperties();
  }, [fetchProperties]);

  useEffect(() => {
    if (user?.role === "buyer") {
      api.myFavorites().then((data) => {
        setFavIds(new Set(data.properties.map((p) => p.id)));
      }).catch(() => {});
    }
  }, [user]);

  const handleToggleFavorite = async (id) => {
    try {
      const res = await api.toggleFavorite(id);
      setFavIds((prev) => {
        const next = new Set(prev);
        if (res.favorited) next.add(id);
        else next.delete(id);
        return next;
      });
    } catch (err) {
      setError(err.message);
    }
  };

  const mappable = properties.filter((p) => p.mapLat && p.mapLng);

  return (
    <div className="listing-page">
      <div className="listing-header">
        <div>
          <h1 className="listing-title">Deals <em>Made for You</em></h1>
          <p className="listing-count">
            {loading ? "Loading…" : `${properties.length} properties available`} · Owner contact shown only after enquiry
          </p>
        </div>
        <div className="view-toggle">
          <button className={view === "grid" ? "active" : ""} onClick={() => setView("grid")}>Grid</button>
          <button className={view === "map" ? "active" : ""} onClick={() => setView("map")}>Map</button>
        </div>
      </div>

      <div className="search-bar">
        <input
          className="search-input"
          placeholder="Search by location, title, or landmark…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="search-input"
          style={{ maxWidth: 160 }}
          value={listingType}
          onChange={(e) => setListingType(e.target.value)}
        >
          <option value="">Rent or Buy</option>
          <option value="buy">For Sale</option>
          <option value="rent">For Rent</option>
        </select>
        <select
          className="search-input"
          style={{ maxWidth: 160 }}
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          <option value="">Sort: Newest</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="area_desc">Area: Largest First</option>
        </select>
      </div>

      <div className="filter-bar">
        {FILTERS.map((f) => (
          <button key={f} className={`filter-btn ${typeFilter === f ? "active" : ""}`} onClick={() => setTypeFilter(f)}>
            {f}
          </button>
        ))}
        <button className="filter-toggle-adv" onClick={() => setShowAdvanced((s) => !s)}>
          {showAdvanced ? "Hide" : "More"} Filters
        </button>
      </div>

      {showAdvanced && (
        <div className="adv-filters">
          <div className="field">
            <label>Min Price (₹)</label>
            <input value={minPrice} onChange={(e) => setMinPrice(e.target.value)} placeholder="0" />
          </div>
          <div className="field">
            <label>Max Price (₹)</label>
            <input value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="No limit" />
          </div>
          <div className="field">
            <label>Min Area (sq.ft)</label>
            <input value={minArea} onChange={(e) => setMinArea(e.target.value)} placeholder="0" />
          </div>
          <div className="field">
            <label>BHK</label>
            <select value={bhk} onChange={(e) => setBhk(e.target.value)}>
              <option value="">Any</option>
              <option value="1 BHK">1 BHK</option>
              <option value="2 BHK">2 BHK</option>
              <option value="3 BHK">3 BHK</option>
              <option value="4 BHK">4 BHK</option>
              <option value="5 BHK">5+ BHK</option>
            </select>
          </div>
        </div>
      )}

      {error && <div className="error-msg">{error}</div>}

      {view === "map" ? (
        <div className="map-wrap">
          <MapContainer center={[13.0827, 80.2707]} zoom={11} style={{ height: "100%", width: "100%" }}>
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {mappable.map((p) => (
              <Marker key={p.id} position={[p.mapLat, p.mapLng]} icon={goldIcon}>
                <Popup>
                  <div className="map-popup">
                    <b>{p.title}</b>
                    <div className="mp-price">{p.price}</div>
                    <div>{p.address}</div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
      ) : (
        <div className="prop-grid">
          {!loading && properties.length === 0 && (
            <div className="no-props">No properties found matching your filters.</div>
          )}
          {properties.map((p) => (
            <PropertyCard
              key={p.id}
              property={p}
              isFavorited={favIds.has(p.id)}
              onToggleFavorite={handleToggleFavorite}
              showFavButton={user?.role === "buyer"}
            />
          ))}
        </div>
      )}
    </div>
  );
}
