import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";

const ICONS = {
  Apartment: "🏢", Villa: "🏠", "Independent House": "🏡",
  Commercial: "🏪", "Plot / Land": "🌿", "Office Space": "🏬",
};

export default function PropertyDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [preferredDate, setPreferredDate] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    api.getProperty(id)
      .then((data) => setProperty(data.property))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  const handleEnquiry = async () => {
    if (!user) return navigate("/auth/buyer");
    if (user.role !== "buyer") return setError("Only buyers can send enquiries.");
    setSending(true);
    setError("");
    try {
      await api.sendEnquiry({ propertyId: id, message, preferredDate });
      setSent(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  };

  if (loading) return <div className="listing-page">Loading…</div>;
  if (!property) return <div className="listing-page error-msg">{error || "Property not found"}</div>;

  const icon = ICONS[property.type] || "🏠";
  const images = property.images && property.images.length > 0 ? property.images : [];

  return (
    <div className="detail-page">
      <button className="back-btn" onClick={() => navigate(-1)} style={{ marginBottom: "1rem" }}>
        ← Back to listings
      </button>

      <div className="detail-gallery">
        {images.length > 0 ? (
          <>
            <img src={images[0]} alt={property.title} />
            <div className="detail-side">
              {images[1] && <img src={images[1]} alt="" />}
              {images[2] && <img src={images[2]} alt="" />}
            </div>
          </>
        ) : (
          <div className="placeholder" style={{ gridColumn: "1/-1" }}>{icon}</div>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "2rem" }}>
        <div>
          <div className="detail-header">
            <div>
              <h1 className="detail-title">{property.title}</h1>
              <p style={{ color: "var(--tm)", fontSize: "0.9rem" }}>
                📍 {property.address} – {property.pincode}
              </p>
            </div>
            <div className="detail-price">
              {property.listingType === "rent" ? `₹${property.price}/mo` : property.price}
            </div>
          </div>

          <div className="detail-specs">
            <div className="spec-item"><span className="spec-val">{property.area}</span><span className="spec-key">Sq. Ft</span></div>
            <div className="spec-item"><span className="spec-val">{property.bhk || "–"}</span><span className="spec-key">Config</span></div>
            <div className="spec-item"><span className="spec-val">{property.facing || "–"}</span><span className="spec-key">Facing</span></div>
            <div className="spec-item"><span className="spec-val">{property.floor || "–"}</span><span className="spec-key">Floor</span></div>
          </div>

          {property.description && (
            <div className="detail-section">
              <h3>Description</h3>
              <p>{property.description}</p>
            </div>
          )}

          {property.amenities && property.amenities.length > 0 && (
            <div className="detail-section">
              <h3>Amenities</h3>
              <div className="amenity-list">
                {property.amenities.map((a) => <span key={a} className="amenity-pill">{a}</span>)}
              </div>
            </div>
          )}

          <div className="detail-section">
            <h3>Location</h3>
            <p>
              {property.landmark && <>Nearby: {property.landmark}<br /></>}
              {property.mapLat && property.mapLng
                ? `GPS: ${property.mapLat}° N, ${property.mapLng}° E`
                : "Map location not provided"}
            </p>
          </div>
        </div>

        <div>
          <div className="enquiry-box">
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: "1.1rem", marginBottom: "0.5rem" }}>
              Interested in this property?
            </h3>
            <p style={{ fontSize: "0.8rem", color: "var(--tm)", marginBottom: "1rem" }}>
              🔒 Owner contact stays private. Send a request and the seller will reach out to confirm.
            </p>
            {sent ? (
              <div className="success-msg">✓ Request sent! The seller will contact you soon.</div>
            ) : (
              <>
                {error && <div className="error-msg">{error}</div>}
                <div className="field">
                  <label>Preferred Visit Date</label>
                  <input type="date" value={preferredDate} onChange={(e) => setPreferredDate(e.target.value)} />
                </div>
                <div className="field">
                  <label>Message</label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="I'm interested in this property, can I schedule a visit?"
                  />
                </div>
                <button className="btn-primary" onClick={handleEnquiry} disabled={sending}>
                  {sending ? <span className="loading-spin" /> : "Request Visit / Contact →"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
