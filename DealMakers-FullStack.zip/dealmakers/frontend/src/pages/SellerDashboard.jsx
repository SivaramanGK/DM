import { useState, useEffect } from "react";
import { api } from "../api";

const AMENITIES = ["Parking", "Gym", "Swimming Pool", "Garden", "Security", "Power Backup", "Lift", "CCTV", "Club House", "Children Play Area", "Water Supply 24/7", "Intercom"];
const PROPERTY_TYPES = ["Apartment", "Villa", "Independent House", "Commercial", "Plot / Land", "Office Space"];
const ICONS = { Apartment: "🏢", Villa: "🏠", "Independent House": "🏡", Commercial: "🏪", "Plot / Land": "🌿", "Office Space": "🏬" };

export default function SellerDashboard() {
  const [tab, setTab] = useState("upload");
  const [myListings, setMyListings] = useState([]);
  const [enquiries, setEnquiries] = useState([]);
  const [loadingList, setLoadingList] = useState(false);

  useEffect(() => {
    if (tab === "mylist") loadMyListings();
    if (tab === "enquiries") loadEnquiries();
  }, [tab]);

  const loadMyListings = () => {
    setLoadingList(true);
    api.myProperties().then((data) => setMyListings(data.properties)).finally(() => setLoadingList(false));
  };
  const loadEnquiries = () => {
    setLoadingList(true);
    api.receivedEnquiries().then((data) => setEnquiries(data.enquiries)).finally(() => setLoadingList(false));
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this listing?")) return;
    await api.deleteProperty(id);
    setMyListings((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div className="seller-page">
      <h1 className="page-heading">Seller Dashboard</h1>
      <p className="page-sub">List and manage your properties. Buyer enquiries are routed here — your contact stays private until you choose to respond.</p>

      <div className="tabs">
        <button className={`tab-btn ${tab === "upload" ? "active" : ""}`} onClick={() => setTab("upload")}>+ Upload Property</button>
        <button className={`tab-btn ${tab === "mylist" ? "active" : ""}`} onClick={() => setTab("mylist")}>My Listings</button>
        <button className={`tab-btn ${tab === "enquiries" ? "active" : ""}`} onClick={() => setTab("enquiries")}>Enquiries Received</button>
      </div>

      {tab === "upload" && <UploadForm onSuccess={() => { setTab("mylist"); loadMyListings(); }} />}

      {tab === "mylist" && (
        <div>
          {loadingList ? (
            <p>Loading…</p>
          ) : myListings.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📭</div><p>No listings yet. Upload your first property.</p></div>
          ) : (
            myListings.map((p) => (
              <div key={p.id} className="my-listing-card">
                {p.images && p.images[0] ? (
                  <img className="mlc-icon" src={p.images[0]} alt="" />
                ) : (
                  <div className="mlc-icon">{ICONS[p.type] || "🏠"}</div>
                )}
                <div className="mlc-info">
                  <div className="mlc-title">{p.title}</div>
                  <div className="mlc-meta">📍 {p.address}, {p.pincode} · {p.area} sq.ft · {p.type} · {p.listingType === "rent" ? "For Rent" : "For Sale"}</div>
                </div>
                <div className="mlc-price">{p.price}</div>
                <button className="mlc-delete" onClick={() => handleDelete(p.id)}>Delete</button>
              </div>
            ))
          )}
        </div>
      )}

      {tab === "enquiries" && (
        <div>
          {loadingList ? (
            <p>Loading…</p>
          ) : enquiries.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📨</div><p>No enquiries yet.</p></div>
          ) : (
            enquiries.map((e) => (
              <div key={e.id} className="enquiry-card">
                <div className="eq-buyer">{e.buyerName}</div>
                <div className="eq-contact">{e.buyerEmail}</div>
                {e.preferredDate && <div style={{ fontSize: "0.8rem", color: "var(--tm)", marginBottom: "0.4rem" }}>Preferred date: {e.preferredDate}</div>}
                <div className="eq-msg">{e.message || "No message provided."}</div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function UploadForm({ onSuccess }) {
  const [form, setForm] = useState({
    title: "", type: "", listingType: "buy", price: "", priceValue: "",
    area: "", bhk: "", floor: "", facing: "", address: "", pincode: "",
    mapLat: "", mapLng: "", landmark: "", description: "",
  });
  const [amenities, setAmenities] = useState(new Set());
  const [images, setImages] = useState([]); // File objects
  const [previews, setPreviews] = useState([]); // object URLs
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const toggleAmenity = (a) => {
    setAmenities((prev) => {
      const next = new Set(prev);
      next.has(a) ? next.delete(a) : next.add(a);
      return next;
    });
  };

  const handleImageSelect = (e) => {
    const files = Array.from(e.target.files).slice(0, 8 - images.length);
    setImages((prev) => [...prev, ...files]);
    setPreviews((prev) => [...prev, ...files.map((f) => URL.createObjectURL(f))]);
  };

  const removeImage = (idx) => {
    setImages((prev) => prev.filter((_, i) => i !== idx));
    setPreviews((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async () => {
    setError("");
    if (!form.title || !form.area || !form.address || !form.pincode) {
      setError("Please fill all required fields: Title, Area, Address, Pincode.");
      return;
    }
    setSubmitting(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      fd.append("amenities", JSON.stringify([...amenities]));
      images.forEach((img) => fd.append("images", img));

      await api.createProperty(fd);
      setSuccess(true);
      setForm({
        title: "", type: "", listingType: "buy", price: "", priceValue: "",
        area: "", bhk: "", floor: "", facing: "", address: "", pincode: "",
        mapLat: "", mapLng: "", landmark: "", description: "",
      });
      setAmenities(new Set());
      setImages([]);
      setPreviews([]);
      setTimeout(() => { setSuccess(false); onSuccess(); }, 1200);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="upload-form">
      {success && <div className="success-msg">✓ Property published! Buyers can now discover it.</div>}
      {error && <div className="error-msg">{error}</div>}

      <div className="form-section-title">Listing Type</div>
      <div className="listing-type-toggle">
        <button className={`lt-toggle-btn ${form.listingType === "buy" ? "on" : ""}`} onClick={() => set("listingType", "buy")}>For Sale</button>
        <button className={`lt-toggle-btn ${form.listingType === "rent" ? "on" : ""}`} onClick={() => set("listingType", "rent")}>For Rent</button>
      </div>

      <div className="form-section-title">Property Details</div>
      <div className="field"><label>Property Title *</label><input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Spacious 3BHK in Anna Nagar" /></div>
      <div className="form-row">
        <div className="field">
          <label>Property Type</label>
          <select value={form.type} onChange={(e) => set("type", e.target.value)}>
            <option value="">Select type</option>
            {PROPERTY_TYPES.map((t) => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div className="field"><label>{form.listingType === "rent" ? "Monthly Rent (₹)" : "Price (₹)"}</label>
          <input value={form.price} onChange={(e) => set("price", e.target.value)} placeholder={form.listingType === "rent" ? "e.g. 25,000" : "e.g. 85,00,000"} />
        </div>
      </div>
      <div className="form-row">
        <div className="field"><label>Price Value (numeric, for filtering)</label><input type="number" value={form.priceValue} onChange={(e) => set("priceValue", e.target.value)} placeholder="e.g. 8500000" /></div>
        <div className="field"><label>Area (Sq. ft.) *</label><input type="number" value={form.area} onChange={(e) => set("area", e.target.value)} placeholder="e.g. 1450" /></div>
      </div>
      <div className="form-row3">
        <div className="field"><label>BHK / Rooms</label><input value={form.bhk} onChange={(e) => set("bhk", e.target.value)} placeholder="e.g. 3 BHK" /></div>
        <div className="field"><label>Floor / Level</label><input value={form.floor} onChange={(e) => set("floor", e.target.value)} placeholder="e.g. 4th of 10" /></div>
        <div className="field">
          <label>Facing Direction</label>
          <select value={form.facing} onChange={(e) => set("facing", e.target.value)}>
            <option value="">Select</option>
            {["North","South","East","West","North-East","North-West","South-East","South-West"].map((d) => <option key={d}>{d}</option>)}
          </select>
        </div>
      </div>

      <div className="form-section-title">Location</div>
      <div className="field"><label>Full Address *</label><input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="Street name, Area, City" /></div>
      <div className="form-row">
        <div className="field"><label>Pincode *</label><input value={form.pincode} onChange={(e) => set("pincode", e.target.value)} placeholder="e.g. 600040" /></div>
        <div className="field"><label>Nearby Landmark</label><input value={form.landmark} onChange={(e) => set("landmark", e.target.value)} placeholder="e.g. Near Metro Station" /></div>
      </div>
      <div className="form-row">
        <div className="field"><label>Map Latitude</label><input value={form.mapLat} onChange={(e) => set("mapLat", e.target.value)} placeholder="e.g. 13.0827" /></div>
        <div className="field"><label>Map Longitude</label><input value={form.mapLng} onChange={(e) => set("mapLng", e.target.value)} placeholder="e.g. 80.2707" /></div>
      </div>
      <p style={{ fontSize: "0.76rem", color: "var(--tm)", marginTop: "-0.6rem", marginBottom: "1rem" }}>
        Tip: open Google Maps, right-click your property's location, and copy the coordinates shown.
      </p>

      <div className="form-section-title">Photos</div>
      <label className="image-upload-zone">
        <input type="file" accept="image/*" multiple onChange={handleImageSelect} style={{ display: "none" }} />
        📷 Click to upload property photos (up to 8, JPG/PNG/WEBP, max 5MB each)
      </label>
      {previews.length > 0 && (
        <div className="image-preview-grid">
          {previews.map((src, i) => (
            <div key={i} className="image-preview">
              <img src={src} alt="" />
              <button className="remove-img" onClick={() => removeImage(i)}>×</button>
            </div>
          ))}
        </div>
      )}

      <div className="form-section-title">Amenities</div>
      <div className="amenity-check">
        {AMENITIES.map((a) => (
          <button key={a} className={`amenity-toggle ${amenities.has(a) ? "on" : ""}`} onClick={() => toggleAmenity(a)}>
            {amenities.has(a) ? "✓ " : "+ "}{a}
          </button>
        ))}
      </div>

      <div className="form-section-title">Description</div>
      <div className="field">
        <textarea value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Describe the property — construction quality, nearby landmarks, unique features, why this is a super deal…" />
      </div>

      <button className="btn-primary" onClick={handleSubmit} disabled={submitting}>
        {submitting ? <span className="loading-spin" /> : "Publish Listing →"}
      </button>
      <p className="privacy-note">🔒 Your mobile number and contact details will NOT be visible to buyers directly</p>
    </div>
  );
}
